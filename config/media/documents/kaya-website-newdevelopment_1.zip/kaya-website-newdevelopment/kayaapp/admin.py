from django.contrib import admin
from . import models
from django.contrib.auth.admin import UserAdmin
from .forms import AddForm, ChangeForm

class CustomUserAdmin(UserAdmin):
    add_form = AddForm
    form = ChangeForm
    list_display = ["email",'first_name',"last_name","gender","age","is_active"]
    list_filter = ['email','is_staff','is_active']
    search_fields = ['email','first_name','last_name']
    ordering = ['email']
    list_display_links = ['email']
    fieldsets = [
        [None, {"fields":["email","password",'first_name','last_name',"age",'gender']}],
        ["Permissions",{"fields":["is_staff","is_active"]}]
    ]
    add_fieldsets = [
        [None, {"classes":["wide"],"fields":['email','password1','password2','age','first_name','last_name',"is_staff","is_active"]}]
    ]

admin.site.register(models.UserRegistration,CustomUserAdmin)

class Form1OptionAdmin(admin.TabularInline):
    model = models.Form1Option


@admin.register(models.Form1UserQuestion)
class Form1UserQuestionAdmin(admin.ModelAdmin):
    inlines = [Form1OptionAdmin]
    list_display = ["question",'options']
    
    def options(self,obj):
        all_options = obj.options.all().values('option')
        data = ""
        for option in all_options:
            data += option['option'] + ', '
        return data


@admin.register(models.SkinType)
class SkinTypeAdmin(admin.ModelAdmin):
    list_display = ['skin_type']


@admin.register(models.Concern)
class ConcernAdmin(admin.ModelAdmin):
    list_display = ['concern_text']


@admin.register(models.Solution)
class SolutionAdmin(admin.ModelAdmin):
    list_display = ['concern','solution_text']

@admin.register(models.AgeGroup)
class AgeGroupAdmin(admin.ModelAdmin):
    list_display = ['age_group_min','age_group_max','id']
    
@admin.register(models.Form1UserAnswer)
class Form1UserAnswerAdmin(admin.ModelAdmin):
    list_display = ['question_answer','user']
    
@admin.register(models.Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name','description','price','product_image','sku_id','product_url','image_url'  ]


    
@admin.register(models.Diagnosis)
class Diagnosis(admin.ModelAdmin):
    list_display = ['user','image']



@admin.register(models.UserReport)
class UserReport(admin.ModelAdmin):
    list_display = ["user", "concerns", "products_user_bought", "skin_type"]
    # readonly_fields = ["user", "concerns", "products_user_bought", "skin_type"]


