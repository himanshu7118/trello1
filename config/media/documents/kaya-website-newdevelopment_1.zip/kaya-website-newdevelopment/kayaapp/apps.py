from django.apps import AppConfig


class KayaappConfig(AppConfig):
    name = 'kayaapp'

    def ready(self) -> None:
        import kayaapp.signals