from django.template import Library
from kayaapp import models
from kayaapp.utils import post_request
register = Library()

@register.filter(name="to_char")
def to_char(value):
    return chr(96 + value)

@register.filter(name="short")
def short(value):
    return value[:10] + "..."



