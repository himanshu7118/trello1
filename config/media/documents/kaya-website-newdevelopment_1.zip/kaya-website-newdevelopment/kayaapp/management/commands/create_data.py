from random import randint
from django.core.management.base import BaseCommand
from kayaapp import models
from random import randint as price
import django


products = ['Gentle Miscellar Foaming Cleanser', 'Intense Hydra Boost Serum', 'Pigmentation Reducing Complex (Night Use)', 'Red Grape & Niacinamide Night Mask', 'Brightening Beads Cleanser', 'Hydrating Night Mask', 'Dramatic Renew Day Cream (40+ age)', 'Creamy Exfoliating Rinse', '5-HERB INSTANT OIL CONTROL FACIAL MASK', 'Brightening Day Cream', 'Soothing Light Day Moisturizer with SPF 25', 'Anytime Moisturizing Cream', 'Brightening Serum/Antox Vit C', 'Purifying Cleanser', 'Soothe & Nourish Night Mask', 'Intense HydraBoost Serum', 'Brightening Serum', 'Regenerating Day Cream', 'Red Grape & Niacinamde Night Mask', 'Absolute Repair Concentrate', 'Luminous Peel Off Mask', 'Daily Use Sunscreen SPF 30', 'Purifying Nourisher', 'Intense Hydra Boost Night Serum', 'Soothing Cleansing Gel ', 'Pigmentation Reducing Complex', 'Lighten & Smoothen Under Eye Gel ', 'EVERYDAY CLEANSING WIPES', 'Refining Mist', 'Purifying Spot Corrector', 'Antox Vit C', 'Dramatic Renew Day Cream (40+ age) ', 'Sensitive Sunscreen SPF 15', 'Daily Pore Minimizing Toner', 'Refreshing Mattifying Wipes', 'Brightening Night ', 'Brightening Serum ', 'Brightening Night Cream', 'Skin Protection Cream', 'Soothing Cleansing Gel', 'Purifying Toner', '4-MARINE INSTA-REVITALIZING FACIAL MASK', 'Blemish Control Formula', 'Overnight Regenerating Nourisher', 'Activated Charcoal Antipollution Face Wash', 'Youth Protect Sunscreen SPF 50', 'Sensitive Cleanser', 'Lighten & Smoothen Under Eye gel', 'Wash', 'Comedone Control Serum', 'Charcoal & Tea Tree Mattifying Peel off mask', 'Flawless Day Cream (30+ age)', 'Replenishing Night Cream (30+ age)', 'Daily Moisturizing Sunscreen SPF 30', 'Brightening & Firming Eye Serum', 'Soothing Light Day Moisturizer with SPF 25 ', 'Green Tea & Vitamin E Night Mask', 'Lighten & Smoothen Under Eye Gel', 'Licorice Luminous Peel Off Mask',"Daily Pore Minimizing Toner",'Derma Wrinkle Repair Serum/Intense Hydra Boost','Serum']

d1 = {}

l1 = [
    "Creamy Exfoliating Rinse", "Refining Mist", "Brightening Serum",
    "Regenerating Day Cream", "Overnight Regenerating Nourisher",
    "Pigmentation Reducing Complex", "Brightening & Firming Eye Serum",
    "Red Grape & Niacinamide Night Mask"
]
l2 = [
    "Creamy Exfoliating Rinse", "Refining Mist", "Antox Vit C",
    "Regenerating Day Cream", "Overnight Regenerating Nourisher",
    "Pigmentation Reducing Complex", "Lighten & Smoothen Under Eye Gel",
    "Red Grape & Niacinamide Night Mask"
]


l3 = [
    "Soothing Cleansing Gel", 
    "Daily Moisturizing Suncreen SPF 30",
    "Anytime Moisturizing Cream", 
    "EVERYDAY CLEANSING WIPES",
    "Hydrating Night Mask",
]


l4 = [
    "Soothing Cleansing Gel", 
    "Youth Protect Sunscreen SPF 50",
    "Anytime Moisturizing Cream", 
    "EVERYDAY CLEANSING WIPES",
    "Hydrating Night Mask",
]


l5 = [
    "Activated Charcoal Antipollution Face Wash",
    "Refining Mist",
    "Brightening Day Cream",
    "Brightening Night Cream",
    "Purifying Spot Corrector (if active pimples)",
    "EVERYDAY CLEANSING WIPES",
    "Luminous Peel Off Mask",
    "Green Tea & Vitamin E Night Mask",
]


l6 = [
    "Creamy Exfoliating Rinse",
    "Daily Pore Minimizing Toner",
    "Brightening Serum", 
    "Regenerating Day Cream",
    "Overnight Regenerating Nourisher",
    "4-MARINE INSTA-REVITALIZING FACIAL MASK",
]

l7 = [
    
    "Brightening Beads Cleanser",
    "Refining Mist",
    "Brightening Day Cream",
    "Brightening Night Cream", 
    "Brightening Serum",
    "Brightening & Firming Eye Serum",
    "Licorice Luminous Peel Off Mask",
    "Red Grape & Niacinamide Night Mask",
]

l8 = [
    "Brightening Beads Cleanser",
    "Refining Mist",
    "Antox Vit C",
    "Brightening Day Cream",
    "Lighten & Smoothen Under Eye Gel",
    "Brightening Night Cream",
    "Licorice Luminous Peel Off Mask",
    "Red Grape & Niacinamide Night Mask",
]


l9 = [
    
    "Soothing Cleansing Gel", 
    "Daily Pore Minimizing Toner",
    "Brightening Day Cream",
    "Anytime Moisturizing Cream",
    "EVERYDAY CLEANSING WIPES",
    "Hydrating Night Mask",
]


l10 = [
    
    "Skin Awakening Rinse",
    "Daily Pore Minimizing Toner",
    "Brightening Day Cream",
    "Derma Wrinkle Repair Serum/Intense Hydra Boost Serum",
    "Brightening Night Cream",
    "EVERYDAY CLEANSING WIPES",
    "Hydrating Night Mask",
]


l11 = [
    "Activated Charcoal Antipollution Face Wash",
    "Purifying Toner",
    "Soothing Light Day Moisturizer with SPF 25",
    "Purifying Spot Corrector (if active pimples)",
    "Anytime Moisturizing Cream",
    "Licorice Luminous Peel Off Mask",
    "EVERYDAY CLEANSING WIPES",
    "Green Tea & Vitamin E Night Mask",
]


l12 = [
    "Brightening Day Cream",
    "Daily Pore Minimizing Toner",
    "Brightening Serum/Antox Vit C",
    "Daily Use Sunscreen SPF 30",
    "Brightening Night Cream",
    "Licorice Luminous Peel Off Mask",
    "5-HERB INSTANT OIL CONTROL FACIAL MASK",
    "Green Tea & Vitamin E Night Mask",
    ]


l13 = [
    "Purifying Cleanser",
    "Purifying Toner",
    "Purifying Nourisher",
    "Refreshing Mattifying Wipes",
    "5-HERB INSTANT OIL CONTROL FACIAL MASK",
]



l14 = [
    "Purifying Cleanser",
    "Purifying Toner",
    "Purifying Spot Corrector",
    "Purifying Nourisher",
]

l15 = [
    "Purifying Cleanser",
    "Purifying Toner",
    "Comedone Control Serum",
    "Purifying Nourisher",
]

l16 = [
    "Purifying Cleanser",
    "Purifying Toner",
    "Blemish Control Formula",
    "Purifying Nourisher",
]

l17 = [
    
    "Activated Charcoal Antipollution Face Wash",
    "Purifying Toner",
    "Purifying Nourisher",
    "Charcoal & Tea Tree Mattifying Peel off mask",
    "Wash"
]

l18 = [
    
    "Tea Tree Purifying Face Wash",
    "Daily Pore Minimizing Toner",
    "Purifying Nourisher",
    "Replenishing night cream",
    "Refreshing Mattifying Wipes",
    
]

l19 = [
    "Purifying Cleanser",
    "Purifying Toner",
    "Purifying Nourisher",
    "Refreshing Mattifying Wipes",
    "5-HERB INSTANT OIL CONTROL FACIAL MASK",
]

l20 = [
    "Sensitive Cleanser",
    "Brightening Serum",
    "Sensitive Sunscreen SPF 15",
    "Soothe & Nourish Night Mask",
]

l21 = [
    "Gentle Miscellar Foaming Cleanser",
    "Soothing Light Day Moisturizer with SPF 25",
    "Intense Hydra Boost Serum",
    "Absolute Repair Concentrate",
]

l22 = [
    "Skin Protection Cream",
    "Soothing Light Day Moisturizer with SPF 25",
    "Intense Hydra Boost Serum",
    "Absolute Repair Concentrate",
]
l23 = [
    "Sensitive Cleanser",
    "Sensitive Sunscreen SPF 15",
    "Intense HydraBoost Serum",
    "Absolute Repair Concentrate",
    "Soothe & Nourish Night Mask",
]


l24 = [
    "Gentle Miscellar Foaming Cleanser", 
    "Anytime Moisturizing Cream", 
    "Sensitive Sunscreen SPF 15",
    "Intense Hydra Boost Serum",
    "4-MARINE INSTA-REVITALIZING FACIAL MASK",
    "Hydrating Night Mask",
]
l25 = [
    "Sensitive Cleanser",
    "Absolute Repair Concentrate",
    "Sensitive Sunscreen SPF 15",
    "Intense Hydra Boost Serum",
    "4-MARINE INSTA-REVITALIZING FACIAL MASK",
    "Hydrating Night Mask",
    "Anytime Moisturizing Cream",
    "Gentle Miscellar Foaming Cleanser"
]

l26 = [
    "Skin Awakening Rinse",
    "Brightening Serum",
    "Brightening Day Cream",
    "Pigmentation Reducing Complex (Night Use)",
    "Brightening Night Cream",
    "Brightening & Firming Eye Serum",
    "Red Grape & Niacinamde Night Mask",
]
l27 = [
    "Skin Awakening Rinse",
    "Antox Vit C",
    "Brightening Day Cream",
    "Pigmentation Reducing Complex (Night Use)",
    "Brightening Night Cream",
    "Lighten & Smoothen Under Eye gel",
    "Red Grape & Niacinamde Night Mask",
]




l28 = [
    "Gentle Miscellar Foaming Cleanser",
    "Youth Protect Sunscreen SPF 50",
    "Intense Hydra Boost Night Serum",
    "Absolute Repair Concentrate",
    "Pigmentation Reducing Complex",
    "4-MARINE INSTA-REVITALIZING FACIAL MASK",
]
l29 = [
    "Gentle Miscellar Foaming Cleanser",
    "Dramatic Renew Day Cream (40+ age)", 
    "Intense Hydra Boost Night Serum",
    "Absolute Repair Concentrate",
    "Brightening & Firming Eye Serum",
    "Pigmentation Reducing Complex",
]
l30 = [
    "Sensitive Cleanser",
    "Flawless Day Cream (30+ age)",
    "Intense Hydra Boost Night Serum",
    "Replenishing Night Cream (30+ age)"
    "Lighten & Smoothen Under Eye Gel", 
    "4-MARINE INSTA-REVITALIZING FACIAL MASK",
]
l31 = [
    "Gentle Miscellar Foaming Cleanser",
    "Dramatic Renew Day Cream (40+ age)", 
    "Intense Hydra Boost Night Serum",
    "Absolute Repair Concentrate",
    "Lighten & Smoothen Under Eye Gel", 
]
l32 = [
    "Sensitive Cleanser",
    "Daily Moisturizing Sunscreen SPF 30",
    "Intense Hydra Boost Night Serum",
    "Replenishing Night Cream (30+ age)",
    "Lighten & Smoothen Under Eye Gel", 
    "4-MARINE INSTA-REVITALIZING FACIAL MASK",
]

class Command(BaseCommand):

    def handle(self, *args, **kwargs):
        try:
            if models.SkinType.objects.all().count() == 0:
                question1 = models.Form1UserQuestion.objects.create(question="How does the Skin on The Forehead & Nose Bridge usually feel?")
                models.Form1Option.objects.create(form1_user_question=question1,option='Oily')
                models.Form1Option.objects.create(form1_user_question=question1,option='Normal')
                models.Form1Option.objects.create(form1_user_question=question1,option='Changes as per environment')
                models.Form1Option.objects.create(form1_user_question=question1,option="Hot and flushed")
                models.Form1Option.objects.create(form1_user_question=question1,option="Dry")
                
                question2 = models.Form1UserQuestion.objects.create(question="How does the Skin on The Sides Of Your Nose Feel?")
                models.Form1Option.objects.create(form1_user_question=question2,option='Oily')
                models.Form1Option.objects.create(form1_user_question=question2,option='Normal')
                models.Form1Option.objects.create(form1_user_question=question2,option='Changes as per environment')
                models.Form1Option.objects.create(form1_user_question=question2,option="Hot and flushed")
                models.Form1Option.objects.create(form1_user_question=question2,option="Dry")

                question3 = models.Form1UserQuestion.objects.create(question="How does the skin on your cheeks feel?")
                models.Form1Option.objects.create(form1_user_question=question3,option='Oily')
                models.Form1Option.objects.create(form1_user_question=question3,option='Normal')
                models.Form1Option.objects.create(form1_user_question=question3,option='Changes as per environment')
                models.Form1Option.objects.create(form1_user_question=question3,option="Hot and flushed")
                models.Form1Option.objects.create(form1_user_question=question3,option="Dry")

                question4 = models.Form1UserQuestion.objects.create(question="Which Of The Following Statements Would You Agree With?")
                models.Form1Option.objects.create(form1_user_question=question4,option="My skin looks extremely shiny and feels sticky-Oily skin")
                models.Form1Option.objects.create(form1_user_question=question4,option="My Skin Is Neither Very Oily Nor Very Dry-Normal skin")
                models.Form1Option.objects.create(form1_user_question=question4,option="I Have An Oily Forehead And Nose Bridge (T Zone)-Combination skin")
                models.Form1Option.objects.create(form1_user_question=question4,option="My skin feels hot,red and flushed with change of temperature/sunexposure-sensitive")
                models.Form1Option.objects.create(form1_user_question=question4,option="None Of The Above.-Dry skin")

                question5 = models.Form1UserQuestion.objects.create(question="Please Select The Option That Best Fits Your Skin Current Skin Behavior after washing your face")
                models.Form1Option.objects.create(form1_user_question=question5,option="Feels fresh and rejuvenated, shine on cheeks, forehead and nose -Oily")
                models.Form1Option.objects.create(form1_user_question=question5,option="My skin feels dry immediately after washing but normalizes in sometime-normal")
                models.Form1Option.objects.create(form1_user_question=question5,option="My cheeks feel a little dry but nose and forehead(T-Zone) feel fresh and shiny-combination")
                models.Form1Option.objects.create(form1_user_question=question5,option="My skin feels red and itchy immediately after washing-sensitive")
                models.Form1Option.objects.create(form1_user_question=question5,option="My skin feels stretched, dry and lifeless-dry skin")

                question6 = models.Form1UserQuestion.objects.create(question="How  Does Your Skin respond to sun exposure/hot humid climate?")
                models.Form1Option.objects.create(form1_user_question=question6,option="My skin feels sticky and looks dark-oily")
                models.Form1Option.objects.create(form1_user_question=question6,option="My skin feels the same-normal")
                models.Form1Option.objects.create(form1_user_question=question6,option="The skin on my nose and forehead tend to become very sticky and shiny-combination")
                models.Form1Option.objects.create(form1_user_question=question6,option="My face feels hot ,flushed and red-sensitive")
                models.Form1Option.objects.create(form1_user_question=question6,option="My face looks lifeless, dull and patchy-dry")

                question7 = models.Form1UserQuestion.objects.create(question="Please select the option that best describes your skin behavior to Moisturisers/Cosmetics")
                models.Form1Option.objects.create(form1_user_question=question7,option="I cannot use anything on my face,I tend to get pimples immediately-Oily ")
                models.Form1Option.objects.create(form1_user_question=question7,option="I don’t usually need a moisturiser and am comfortable with cosmetics-normal")
                models.Form1Option.objects.create(form1_user_question=question7,option="I usually only apply moisturiser on my cheeks and don’t get the right kind of cosmetics.The skin on my T-Zone differs from full face-Combination")
                models.Form1Option.objects.create(form1_user_question=question7,option="My skin tends to breakout into rashes,so I use only particular products-sensitive")
                models.Form1Option.objects.create(form1_user_question=question7,option="My skin feels stretched, lifeless, patchy .Need to apply moisturiser atleast 1-2 times a day-dry")
                
                skin_type = models.SkinType.objects.create(skin_type='Normal')
                concern1 = models.Concern.objects.create(skin_type=skin_type,concern_text='Pigmentation, Uneven skin tone / tanned skin')
                solution = models.Solution.objects.create(concern=concern1,solution_text="Radiance & Glow, even skin tone")
                models.Service.objects.create(service_text=["Kaya Gold Riche Face The","Antox Ultra Sheen Therapy","Aqua Fairness Luxe","Kaya Safe Glow Therapy","Insta Skin Brilliance-after Doctors Consultation"],solution=solution)
                a1 = models.AgeGroup.objects.create(concern=concern1,age_min_val=0,age_max_val=35)
                a2 = models.AgeGroup.objects.create(concern=concern1,age_min_val=36,age_max_val=100)

                concern2 = models.Concern.objects.create(skin_type=skin_type,concern_text='Dehydrated, dry')
                solution = models.Solution.objects.create(concern=concern2,solution_text="Hydration")
                models.Service.objects.create(service_text=["Kaya Safe Glow Therapy","Luxe Deep Sea Youth Boost Therapy","Derma Regen Four Layer Therapy-Normal to Dry Skin"],solution=solution)
                a3 = models.AgeGroup.objects.create(concern=concern2,age_min_val=0,age_max_val=35)
                a4 = models.AgeGroup.objects.create(concern=concern2,age_min_val=36,age_max_val=100)

                concern3 = models.Concern.objects.create(skin_type=skin_type,concern_text='Slightly oily, occassional breakout/acne')
                solution = models.Solution.objects.create(concern=concern3,solution_text="Oil-Control")
                models.Service.objects.create(service_text=["Skin Purify Clear Fresh","Peels-after doctors consultation"],solution=solution)
                a5 = models.AgeGroup.objects.create(concern=concern3,age_distribution=True)

                concern4 = models.Concern.objects.create(skin_type=skin_type,concern_text='Maintainance')
                solution = models.Solution.objects.create(concern=concern4,solution_text="Maintainance")
                models.Service.objects.create(service_text=["Kaya Signature Face Therapy Ultra Detox","Kaya Safe Glow Therapy","Kaya Signature Face Therapy Ultra Rejuv"],solution=solution)
                a6 = models.AgeGroup.objects.create(concern=concern4,age_distribution=True)

                skin_type = models.SkinType.objects.create(skin_type='Combination')
                concern1 = models.Concern.objects.create(skin_type=skin_type,concern_text='Pigmentation, dull, Uneven skin tone / tanned skin')
                solution = models.Solution.objects.create(concern=concern1,solution_text="Radiance & Glow, even skin tone")
                models.Service.objects.create(service_text=["Kaya Gold Riche Face Therapy","Antox Ultra Sheen Therapy","Aqua Fairness Luxe","Kaya Safe Glow Therapy","Peels-after doctors consultation,Derma Regen Four Layer Therapy-Normal to Oily"],solution=solution)
                a7 = models.AgeGroup.objects.create(concern=concern1,age_min_val=0,age_max_val=35)
                a8 = models.AgeGroup.objects.create(concern=concern1,age_min_val=36,age_max_val=100)

                concern2 = models.Concern.objects.create(skin_type=skin_type,concern_text='Dehydrated, dry')
                solution = models.Solution.objects.create(concern=concern2,solution_text="Hydration")
                models.Service.objects.create(service_text=[
                    "Antox Ultra Sheen Therapy",            
                    "Kaya Safe Glow Therapy,Derma Regen Four Layer", 
                    "Therapy-normal to oily"    
                    ],solution=solution)
                a9 = models.AgeGroup.objects.create(concern=concern2,age_min_val=0,age_max_val=35)
                a10 = models.AgeGroup.objects.create(concern=concern2,age_min_val=36,age_max_val=100)

                concern3 = models.Concern.objects.create(skin_type=skin_type,concern_text='Slightly oily, occassional breakout/acne')
                solution = models.Solution.objects.create(concern=concern3,solution_text="Oil-Control")
                models.Service.objects.create(service_text=["Kaya Safe Glow Therapy","Skin Purify Clear Fresh","Peels-after doctors consultation"],solution=solution)
                a11 = models.AgeGroup.objects.create(concern=concern3,age_distribution=True)

                concern4 = models.Concern.objects.create(skin_type=skin_type,concern_text='Maintainance')
                solution = models.Solution.objects.create(concern=concern4,solution_text="Maintainance")
                a12 = models.AgeGroup.objects.create(concern=concern4,age_distribution=True)
                models.Service.objects.create(service_text=[
                    "Kaya Gold Riche Face Therapy",
                    "Antox Ultra Sheen Therapy",
                    "Aqua Fairness Luxe",
                    "Kaya Safe Glow Therapy"
                    ],solution=solution)

                skin_type = models.SkinType.objects.create(skin_type='Oily')
                concern1 = models.Concern.objects.create(skin_type=skin_type,concern_text='Acne-prone')
                solution = models.Solution.objects.create(concern=concern1,solution_text="Oil-Control, Matte look")
                a13 = models.AgeGroup.objects.create(concern=concern1,age_distribution=True)
                models.Service.objects.create(service_text=[
                    "Pure Pore Clear Skin",
                    "Clear Matte therapy",
                    "Skin Purify Clear Fresh",
                    "Kaya Safe Glow Therapy",
                    "Aqua Fairness Luxe",
                    "Peels - after doctors consultation",
                    ],solution=solution)

                concern2 = models.Concern.objects.create(skin_type=skin_type,concern_text='Active pimples, inflammation')
                solution = models.Solution.objects.create(concern=concern2,solution_text="Soothing Pimples, reduce inflammation, oil-control")
                a14 = models.AgeGroup.objects.create(concern=concern2,age_distribution=True)
                models.Service.objects.create(service_text=[
                    "Pure Pore Clear Skin",
                    "Clear Matte therapy",
                    "Skin Purify Clear Fresh",
                    "Kaya Safe Glow Therapy",
                    "Aqua Fairness Luxe",
                    "Peels - after doctors consultation",
                    ],solution=solution)

                concern3 = models.Concern.objects.create(skin_type=skin_type,concern_text='Comedones')
                solution = models.Solution.objects.create(concern=concern3,solution_text="Oil-Control, Matte look, prevent comedones")
                a15 = models.AgeGroup.objects.create(concern=concern3,age_distribution=True)
                models.Service.objects.create(service_text=[
                    "Pure Pore Clear Skin",
                    "Clear Matte therapy",
                    "Skin Purify Clear Fresh",
                    "Kaya Safe Glow Therapy",
                    "Aqua Fairness Luxe",
                    "Peels - after doctors consultation",
                    ],solution=solution)

                concern4 = models.Concern.objects.create(skin_type=skin_type,concern_text='Comedones & acne marks')
                solution = models.Solution.objects.create(concern=concern4,solution_text="Oil-Control, Reduce acne marks, reduce/prevent comedones")
                a16 = models.AgeGroup.objects.create(concern=concern4,age_distribution=True)
                models.Service.objects.create(service_text=[
                    "Pure Pore Clear Skin",
                    "Clear Matte therapy",
                    "Skin Purify Clear Fresh",
                    "Kaya Safe Glow Therapy",
                    "Aqua Fairness Luxe",
                    "Peels - after doctors consultation",
                    ],solution=solution)
                
                concern5 = models.Concern.objects.create(skin_type=skin_type,concern_text='Dull, uneven skin tone')
                solution = models.Solution.objects.create(concern=concern5,solution_text="Oil-Control, Radiance & Glow, even skin tone")
                a17 = models.AgeGroup.objects.create(concern=concern5,age_distribution=True)
                models.Service.objects.create(service_text=[
                    "Pure Pore Clear Skin",
                    "Clear Matte therapy",
                    "Skin Purify Clear Fresh",
                    "Kaya Safe Glow Therapy",
                    "Aqua Fairness Luxe",
                    "Peels - after doctors consultation",
                    ],solution=solution)
                
                concern6 = models.Concern.objects.create(skin_type=skin_type,concern_text='Dehydrated')
                solution = models.Solution.objects.create(concern=concern6,solution_text="")
                a18 = models.AgeGroup.objects.create(concern=concern6,age_distribution=True)
                models.Service.objects.create(service_text=[
                    "Pure Pore Clear Skin",
                    "Clear Matte therapy",
                    "Skin Purify Clear Fresh",
                    "Kaya Safe Glow Therapy",
                    "Aqua Fairness Luxe"
                    ],solution=solution)
                
                concern7 = models.Concern.objects.create(skin_type=skin_type,concern_text='Maintainance')
                solution = models.Solution.objects.create(concern=concern7,solution_text="")
                a19 = models.AgeGroup.objects.create(concern=concern7,age_distribution=True)
                models.Service.objects.create(service_text=[
                    "Pure Pore Clear Skin",
                    "Clear Matte therapy",
                    "Skin Purify Clear Fresh",
                    "Kaya Safe Glow Therapy",
                    "Aqua Fairness Luxe",
                    "Peels - after doctors consultation"
                    ],solution=solution)
                
                
                
                skin_type = models.SkinType.objects.create(skin_type='Sensitive')
                concern1 = models.Concern.objects.create(skin_type=skin_type,concern_text='Pigmentation, dull, uneven skin tone')
                solution = models.Solution.objects.create(concern=concern1,solution_text="Radiance & Glow, even skin tone")
                a20 = models.AgeGroup.objects.create(concern=concern1,age_distribution=True)
                models.Service.objects.create(service_text=[
                    "Kaya Soothe And Balance",
                    "Kaya safe Glow Therapy",
                    "PhotoFacial",
                    ],solution=solution)

                concern2 = models.Concern.objects.create(skin_type=skin_type,concern_text='Dry, dehydrated skin')
                solution = models.Solution.objects.create(concern=concern2,solution_text="Hydration")
                a21 = models.AgeGroup.objects.create(concern=concern2,age_distribution=True)
                models.Service.objects.create(service_text=[
                    "Kaya Soothe And Balance",
                    "Kaya safe Glow Therapy",
                    ],solution=solution)

                concern3 = models.Concern.objects.create(skin_type=skin_type,concern_text='Inflammed skin')
                solution = models.Solution.objects.create(concern=concern3,solution_text="Soothing, hydration")
                a22 = models.AgeGroup.objects.create(concern=concern3,age_distribution=True)
                models.Service.objects.create(service_text=[
                    "Kaya Soothe And Balance",
                    "Kaya safe Glow Therapy"],solution=solution)

                concern4 = models.Concern.objects.create(skin_type=skin_type,concern_text='Sensitive')
                solution = models.Solution.objects.create(concern=concern4,solution_text="Maintainance")
                a23 = models.AgeGroup.objects.create(concern=concern4,age_distribution=True)
                models.Service.objects.create(service_text=[
                    "Kaya Soothe And Balance",
                    "Kaya safe Glow Therapy"],solution=solution)
                
                
                
                skin_type = models.SkinType.objects.create(skin_type='Dry')
                concern1 = models.Concern.objects.create(skin_type=skin_type,concern_text='Dehydrated skin')
                solution = models.Solution.objects.create(concern=concern1,solution_text="Hydration")
                a24 = models.AgeGroup.objects.create(concern=concern1,age_min_val=0,age_max_val=35)
                a25 = models.AgeGroup.objects.create(concern=concern1,age_min_val=36,age_max_val=100)
                models.Service.objects.create(service_text=[
                    "Derma Regen Four Layer Therapy-normal to dry",
                    "Luxe Deep Sea Youth Boost",
                    ],solution=solution)

                concern2 = models.Concern.objects.create(skin_type=skin_type,concern_text='Dull uneven skin tone, pigmentation')
                solution = models.Solution.objects.create(concern=concern2,solution_text="Radiance & Glow, even skin tone")
                a26 = models.AgeGroup.objects.create(concern=concern2,age_min_val=0,age_max_val=35)
                a27 = models.AgeGroup.objects.create(concern=concern2,age_min_val=36,age_max_val=100)
                models.Service.objects.create(service_text=[
                    "Active Marine Ultra Lumiere Facial",
                    "Lighten and Detan",
                    "Intense White Luxe",
                    "Kaya Signature Face Therapy-Ultra detox",
                    "Kaya Signature Face Therapy-Ultra Rejuv",
                    "Kaya Safe Glow Therapy",
                    "Peel-after doctors consultation",
                    "Insta skin Brilliance-after doctors consultation",
                    ],solution=solution)

                concern3 = models.Concern.objects.create(skin_type=skin_type,concern_text='Ageing skin, age spots')
                solution = models.Solution.objects.create(concern=concern3,solution_text="Anti-ageing, hydration, reduce age spots")
                a28 = models.AgeGroup.objects.create(concern=concern3,age_min_val=0,age_max_val=40)
                a29 = models.AgeGroup.objects.create(concern=concern3,age_min_val=41,age_max_val=100)
                models.Service.objects.create(service_text=[
                    "Derma Regen Four Layer Therapy",
                    "Luxe Deep Sea Youth Boost",
                    "Peel-after doctors consultation",
                    "Insta skin Brilliance-after doctors consultation",
                    ],solution=solution)

                concern4 = models.Concern.objects.create(skin_type=skin_type,concern_text='Fine lines')
                solution = models.Solution.objects.create(concern=concern4,solution_text="Anti-ageing, collagen boosting, hydration")
                a30 = models.AgeGroup.objects.create(concern=concern4,age_min_val=0,age_max_val=40)
                models.Service.objects.create(service_text=[
                    "Kaya Safe Glow Therapy",
                    "Kaya Signature Face Therapy-Ultra Rejuv",
                    ],solution=solution)

                concern5 = models.Concern.objects.create(skin_type=skin_type,concern_text='Crow"s feet')
                solution = models.Solution.objects.create(concern=concern5,solution_text="Anti-ageing, collagen boosting, hydration")
                a31 = models.AgeGroup.objects.create(concern=concern5,age_min_val=41,age_max_val=100)
                models.Service.objects.create(service_text=[
                    "Derma Regen Four Layer Therapy",
                    "Luxe Deep Sea Youth Boost",
                    ],solution=solution)
                
                concern6 = models.Concern.objects.create(skin_type=skin_type,concern_text='Anti-ageing, Maintainance')
                solution = models.Solution.objects.create(concern=concern6,solution_text="Anti-ageing, Maintainance")
                a32 = models.AgeGroup.objects.create(concern=concern6,age_min_val=0,age_max_val=41)
                models.Service.objects.create(service_text=[
                    "Kaya Signature Face Therapy-Ultra detox",
                    "Kaya Signature Face Therapy-Ultra Rejuv",
                    "Derma Regen Four Layer Therapy",
                    "Luxe Deep Sea Youth Boost",
                    ],solution=solution)
                
                
                for i in products:
                    d1[i] = []
                    if i in l1:
                        d1[i].append(a1.id)
                    if i in l2:
                        d1[i].append(a2.id)
                    if i in l3:
                        d1[i].append(a3.id)
                    if i in l4:
                        d1[i].append(a4.id)
                    if i in l5:
                        d1[i].append(a5.id)
                    if i in l6:
                        d1[i].append(a6.id)
                    if i in l7:
                        d1[i].append(a7.id)
                    if i in l8:
                        d1[i].append(a8.id)
                    if i in l9:
                        d1[i].append(a9.id)
                    if i in l10:
                        d1[i].append(a10.id)
                    if i in l11:
                        d1[i].append(a11.id)
                    if i in l12:
                        d1[i].append(a12.id)
                    if i in l13:
                        d1[i].append(a13.id)
                    if i in l14:
                        d1[i].append(a14.id)
                    if i in l15:
                        d1[i].append(a15.id)
                    if i in l16:
                        d1[i].append(a16.id)
                    if i in l17:
                        d1[i].append(a17.id)
                    if i in l18:
                        d1[i].append(a18.id)
                    if i in l19:
                        d1[i].append(a19.id)
                    if i in l20:
                        d1[i].append(a20.id)
                    if i in l21:
                        d1[i].append(a21.id)
                    if i in l22:
                        d1[i].append(a22.id)
                    if i in l23:
                        d1[i].append(a23.id)
                    if i in l24:
                        d1[i].append(a24.id)
                    if i in l25:
                        d1[i].append(a25.id)
                    if i in l26:
                        d1[i].append(a26.id)
                    if i in l27:
                        d1[i].append(a27.id)
                    if i in l28:
                        d1[i].append(a28.id)
                    if i in l29:
                        d1[i].append(a29.id)
                    if i in l30:
                        d1[i].append(a30.id)
                    if i in l31:
                        d1[i].append(a31.id)
                    if i in l32:
                        d1[i].append(a32.id)

                d2 = d1.copy()
                for i in d2:
                    if len(d1[i]) == 0:
                        d1.pop(i)
                for k,v in d1.items():
                    models.Product.objects.create(name=k,price=price(100,999),group_id=v)
                self.stdout.write(self.style.SUCCESS('fake data added to database...'))
            else:
                self.stdout.write(self.style.ERROR('Some data are there...Can not create data'))
        except django.db.utils.ProgrammingError:
            self.stdout.write(self.style.ERROR('No table found... Fierst ceate table by makemigrations and migarte command'))
            
            
