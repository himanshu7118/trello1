from .models import UserRegistration
from django.contrib.auth.forms import UserChangeForm, UserCreationForm

class ChangeForm(UserChangeForm):
    class Meta:
        model = UserRegistration
        fields = ['email','first_name','last_name','age','gender']
    
class AddForm(UserCreationForm):
    class Meta:
        model = UserRegistration
        fields = ['email',]