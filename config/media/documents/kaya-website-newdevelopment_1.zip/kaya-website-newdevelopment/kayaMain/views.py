from django.shortcuts import render

# Create your views here.

def kaya_main(request):
    return render(request,'main.html')