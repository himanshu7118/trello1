let video = document.getElementById("video")
let model;
let canvas = document.getElementById("canvas")
let canvas2 = document.getElementById("canvas2")


let ctx = canvas.getContext("2d");
let ctx2 = canvas2.getContext("2d");
var message = " "

const setupCamera = () => {
    
    navigator.mediaDevices
        .getUserMedia({
            video: { width: 600, height: 400 },
            audio: false,
        })
        .then((stream) => {
            video.srcObject = stream;
        });
        
};

const detectFaces = async () => {
    $('#status').fadeOut(); // will first fade out the loading animation
    $('#preloader').delay(0).fadeOut(); // will fade out the white DIV that covers the website.
    $('body').delay(0).css({'overflow':'visible'});

    const prediction = await model.estimateFaces(video, false);
    var c = document.getElementById("demoimage")
    ctx.drawImage(video, -100, 0, 600, 500)

    ctx.drawImage(c, 0, -80, 440, 515)

    prediction.forEach((pred) => {
        ctx.beginPath();
        ctx.lineWidth = "4";
        ctx.strokeStyle = "green";
        // ctx.rect(
        //     pred.topLeft[0],
        //     pred.topLeft[1],
        //     pred.bottomRight[0]-pred.topLeft[0],
        //     pred.bottomRight[1]-pred.topLeft[1],
        // );
        
        ctx.stroke()

        $(document).ready(function () {
            var image = document.getElementById('loaderimage')
            image.style.display='none'
            $("#click").prop("disabled", false);
          })



        if (pred.bottomRight[0] >= 470 || pred.topLeft[0] <= 180 || pred.bottomRight[1] >= 300 || pred.topLeft[1] <= 80 ){
            ctx.font= "bold 20px arial";
            ctx.fillStyle = "red";

            message = "please look at the camera"
            ctx.fillText(message,105, 80)
            $(document).ready(function () {
                $("#click").prop("disabled", true);
              })
        } 
        else if (pred.bottomRight[0] - pred.topLeft[0] <= 150){
            
            ctx.font = "bold 20px arial";
            ctx.fillStyle = "red";

            message = "Please come closer to the camera"
            ctx.fillText(message,70, 80)
            $(document).ready(function () {
                $("#click").prop("disabled", true);
              })
        }
        else if (pred.bottomRight[0] <= 470 && pred.topLeft[0] >= 200 && pred.bottomRight[1]<=290){
            // debugger
            
            ctx.font = "bold 20px arial";
            ctx.fillStyle = "green";
            message = "Perfect! Hold still"
            ctx.fillText(message,130, 80)
            setTimeout(function(){
                    var ss_button = document.getElementById("click")
                    ss_button.click()

             }, 100);
            var ss_button = document.getElementById("click")
             $(document).ready(function () {
                $("#click").prop("disabled", true);
            })
        }
    })
}

const detectFaces2 = async () => {
    const prediction = await model.estimateFaces(video, false);
    var x = ctx2.drawImage(video, -100, 0, 600, 500)
    var img = new Image();
    img.src = canvas2.toDataURL();
    var image = document.createElement("INPUT");
    image.setAttribute("type", "file");
    document.getElementById('delete').style.display = "block"

    image.value = canvas2.toDataURL()  

    
    // document.body.appendChild(img);
    canvas2.style.display = "hide"
}

setupCamera();
video.addEventListener("loadeddata", async () => {
    model = await blazeface.load();
    setInterval(detectFaces, 0)
})
canvas2.style.display="none"
document.getElementById("click").addEventListener("click", async function (event) {
    event.preventDefault()  
    model = await blazeface.load();
    canvas.style.display = "none"
    canvas.style.height = "400px"
    canvas2.style.borderRadius="50px"
    canvas2.style.display="block"
    document.getElementById("delete").innerHTML = "<img style='height:20px;margin-right:0px;' src= '/static/images/r.png'>"

    document.getElementById("delete").style.opacity = '1'

    document.getElementById("delete").disabled = false;
    document.getElementById("submit").disabled = false;

    detectFaces2();
})

document.getElementById("delete").addEventListener("click", async function () {
    canvas2.style.display = "none"
    canvas.style.display="block"
    document.getElementById("submit").disabled = true;
    detectFaces()
})