from django.urls import path,include
from kayaapp import views

urlpatterns = [
    path('imageupload/',views.imageupload, name = 'imageupload'),
    path('imageupload/upload-cam',views.open_cam, name = 'opencamera'),
    path('user-report/<id>/',views.user_report, name = 'user-report'),
    path('logout/',views.logout_view, name = 'logout'),
    path('login/',views.login_view, name = 'login'),
    path('form1/', views.form1_vew, name="form1"),
    path('product-detail/', views.product_detail_view, name="product-detail"),
    path('skin-type/<skin_type>/', views.skin_type_view, name="skin-type"),
    path('prescription',views.prescription ,name='prescription'),
    path('dashboard/', views.user_dashboard_view, name="dashboard"),
    path('upload-cam',views.test, name="upload-cam"),
    path('camera',views.upload_img, name="camera"),
    path('signup',views.signup,name="signup"),

    path('intro1/',views.intro1, name="intro1"),
    path('intro2/',views.intro2, name="intro2"),
    
    
]
api_urls = [
    path('api/', include("kayaapp.api.urls")),
    
]
urlpatterns += api_urls