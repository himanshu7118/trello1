from django.urls import path
from . import views

urlpatterns = [
    path('image/',views.image_upload, name = 'image'),
    path('form-api/', views.Form1QuestionAPIView.as_view(), name="form-api"),
    path('get-products/', views.get_products, name="get-products"),
    path('save-user-report/', views.UserReportApiView.as_view(), name="save-user-report"),
]