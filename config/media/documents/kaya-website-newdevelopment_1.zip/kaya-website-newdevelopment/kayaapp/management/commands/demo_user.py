from django.core.management.base import BaseCommand
import django
from kayaapp.models import UserRegistration as User

class Command(BaseCommand):

    def handle(self, *args, **kwargs):
        try:
            email = "admin@admin.com"
            password = "admin"
            if not User.objects.filter(email=email).exists():
                User.objects.create_superuser(id="123456789123456789hhddhhddhhdd",email=email,password=password,first_name="Super",last_name="Admin",gender="Male",age="35")
                self.stdout.write(self.style.SUCCESS(f'Supersuser created: {email=} and {password=}'))
            else:
                self.stdout.write(self.style.SUCCESS(f'Supersuser Already created: {email=} and {password=}'))
        except django.db.utils.ProgrammingError:
            self.stdout.write(self.style.ERROR('No table found... Fierst ceate table by makemigrations and migarte command'))

