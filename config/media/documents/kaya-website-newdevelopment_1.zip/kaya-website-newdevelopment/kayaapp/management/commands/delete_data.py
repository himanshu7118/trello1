from random import randint as price
from django.core.management.base import BaseCommand
from kayaapp import models
import django

class Command(BaseCommand):

    def handle(self, *args, **kwargs):
        try:
            inp = input("Do you want to delete Product, AgeGroup, Service, Solution, SkinType, Form1, User data ?:[y/n] ").lower()
            if inp == "y" or inp == "yes":
                models.Product.objects.all().delete()
                models.AgeGroup.objects.all().delete()
                models.Service.objects.all().delete()
                models.Solution.objects.all().delete()
                models.Concern.objects.all().delete()
                models.SkinType.objects.all().delete()
                models.Form1UserAnswer.objects.all().delete()
                models.Form1Option.objects.all().delete()
                models.Form1UserQuestion.objects.all().delete()
                models.Diagnosis.objects.all().delete()
                models.UserRegistration.objects.all().delete()
                self.stdout.write(self.style.SUCCESS('data deleted successfully'))
            else:
                self.stdout.write(self.style.SUCCESS('Thank you...Your data are safe'))
        except django.db.utils.ProgrammingError:
            self.stdout.write(self.style.ERROR('No table found... Fierst ceate table by makemigrations and migarte command'))

