from django.urls import path
from .views import kaya_main

urlpatterns = [
    path("",kaya_main)
]