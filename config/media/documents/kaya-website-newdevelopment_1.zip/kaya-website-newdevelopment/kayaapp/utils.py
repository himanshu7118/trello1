from django.urls import reverse
from django.shortcuts import redirect
import json, requests, base64
from django.conf import settings
from django.shortcuts import redirect, render, get_object_or_404
from django.urls.base import reverse
from . import models

headers = {
    "Content-Type": "application/json"
}
def decrypt_customer_id(encoded_id):
    try:
        customerId = base64.b64decode(encoded_id).decode()
        return False, customerId
    except:
        return True, None

def post_request(end_point,data={},token=None):
    if token:
        headers['Authorization'] = f"Bearer {token}"
    response = requests.post(settings.KAYA['kaya_base_url'] + end_point,data=json.dumps(data),headers=headers)
    return response.status_code, response.json()

def get_admin_token():
    data = {
        "username" : settings.KAYA['admin_username'],
        "password" : settings.KAYA['admin_password']
    }
    return post_request("/rest/V1/integration/admin/token",data=data)

def get_customer_token(customerId,admin_token):
    data = {
        "customerId" : customerId
    }
    return post_request("/rest/V1/ranosys-kaya/checkcustomertoken",data=data,token=admin_token)

def get_qoute_id(customerId,cstomerToken):
    end_point = "/rest/V1/carts/mine"
    data = {
        "customerId" : customerId
    }
    _, qoute_id = post_request(end_point,data=data,token=cstomerToken)
    return qoute_id


def renew_customer_and_admin_token(view_func):
    def wrapper(request,*args,**kwargs):
        # breakpoint()
        status_code,admin_token = get_admin_token()
        if status_code == 200:
            request.session['admin_token'] = admin_token
        status_code,customer_token = get_customer_token(request.user.id,request.session['admin_token'])
        if status_code:
            request.user.token = customer_token
        request.user.save()
        return view_func(request,*args,**kwargs)
    return wrapper
