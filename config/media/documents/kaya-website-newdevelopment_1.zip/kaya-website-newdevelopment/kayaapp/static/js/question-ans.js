const boxone = document.querySelector(".box-one");
const boxtwo = document.querySelector(".box-two");
const boxthree = document.querySelector(".box-three");
const boxfour = document.querySelector(".box-four");
const boxfive = document.querySelector(".box-five");
const boxsix = document.querySelector(".box-six");
const boxseven = document.querySelector(".box-seven");
const boxeight = document.querySelector(".box-eight");
const boxnine = document.querySelector(".box-nine");
const boxten = document.querySelector(".box-ten");
const boxeleven = document.querySelector(".box-eleven");
const boxtwelve = document.querySelector(".box-twelve");
const boxthirteen = document.querySelector(".box-thirteen");
const btnone = document.querySelector(".nxtbtn-one");
const btntwo = document.querySelector(".nxtbtn-two");
const btnthree = document.querySelector(".nxtbtn-three");
const btnfour = document.querySelector(".nxtbtn-four");
const btnfive = document.querySelector(".nxtbtn-five");
const btnsix = document.querySelector(".nxtbtn-six");
const btnseven = document.querySelector(".nxtbtn-seven");
const btneight = document.querySelector(".nxtbtn-eight");
const btnnine = document.querySelector(".nxtbtn-nine");
const btnten = document.querySelector(".nxtbtn-ten");
const btneleven = document.querySelector(".nxtbtn-eleven");
const btntwelve = document.querySelector(".nxtbtn-twelve");
const btnthirteen = document.querySelector(".nxtbtn-thirteen");
const pegone = document.querySelector(".page-item .page-link-one");
const pegtwo = document.querySelector(" .page-item .page-link-two");
const pegthree = document.querySelector(".page-item .page-link-three");
const pegfour = document.querySelector(".page-item .page-link-four");
const pegfive = document.querySelector(".page-item .page-link-five");
const pegsixes = document.querySelector(".page-item .page-link-six");
const pegsevens = document.querySelector(".page-item .page-link-seven");
const pegeight = document.querySelector(".page-item .page-link-eight");
const pegnine = document.querySelector(".page-item .page-link-nine");
const pegten = document.querySelector(".page-item .page-link-ten");
const pegeleven = document.querySelector(".page-item .page-link-eleven");
const pegtwelve = document.querySelector(".page-item .page-link-twelve");
const pegthirteen = document.querySelector(".page-item .page-link-thirteen");
 pegone.classList.add("bg-dark");
 pegone.classList.add("text-light");
btnone.onclick = ()=>{
        boxtwo.classList.add("activeInfo");
     boxone.classList.add("inactiveInfo"); 
    pegtwo.classList.add("bg-dark");
    pegtwo.classList.add("text-light");
    pegone.classList.remove("bg-dark");
    pegone.classList.remove("text-light");
}
btntwo.onclick = ()=>{
        boxthree.classList.add("activeInfo");
     boxtwo.classList.add("inactiveInfo"); 
    pegthree.classList.add("bg-dark");
	pegthree.classList.add("text-light");
     pegtwo.classList.remove("bg-dark");
	 pegtwo.classList.remove("text-light");
}

btnthree.onclick = ()=>{
        boxfour.classList.add("activeInfo");
     boxthree.classList.add("inactiveInfo"); 
     pegfour.classList.add("bg-dark");
	  pegfour.classList.add("text-light");
     pegthree.classList.remove("bg-dark");
	  pegthree.classList.remove("text-light");
    
}
btnfour.onclick = ()=>{
        boxfive.classList.add("activeInfo");
     boxfour.classList.add("inactiveInfo"); 
    pegfive.classList.add("bg-dark");
 pegfive.classList.add("text-light");
pegfour.classList.remove("bg-dark");
	  pegfour.classList.remove("text-light");
    
}
btnfive.onclick = ()=>{
        boxsix.classList.add("activeInfo");
     boxfive.classList.add("inactiveInfo");
     pegsixes.classList.add("bg-dark");
	 pegsixes.classList.add("text-light");
     pegfive.classList.remove("bg-dark");
	 pegfive.classList.remove("text-light");
    
}
btnsix.onclick = ()=>{
        boxseven.classList.add("activeInfo");
     boxsix.classList.add("inactiveInfo");
     pegsevens.classList.add("bg-dark");
	  pegsevens.classList.add("text-light");
     pegsixes.classList.remove("bg-dark");
	   pegsixes.classList.remove("text-light");
    
}
btnseven.onclick = ()=>{
        boxeight.classList.add("activeInfo");
     boxseven.classList.add("inactiveInfo");
     pegeight.classList.add("bg-dark");
  pegeight.classList.add("text-light");
     pegsevens.classList.remove("bg-dark");
	   pegsevens.classList.remove("text-light");
    
}
btneight.onclick = ()=>{
        boxnine.classList.add("activeInfo");
     boxeight.classList.add("inactiveInfo");
     pegnine.classList.add("bg-dark");
  pegnine.classList.add("text-light");
     pegeight.classList.remove("bg-dark");
	   pegeight.classList.remove("text-light");
    
}
btnnine.onclick = ()=>{
        boxten.classList.add("activeInfo");
     boxnine.classList.add("inactiveInfo");
     pegten.classList.add("bg-dark");
  pegten.classList.add("text-light");
     pegnine.classList.remove("bg-dark");
	   pegnine.classList.remove("text-light");
    
}
btnten.onclick = ()=>{
        boxeleven.classList.add("activeInfo");
     boxten.classList.add("inactiveInfo");
     pegeleven.classList.add("bg-dark");
  pegeleven.classList.add("text-light");
     pegten.classList.remove("bg-dark");
	   pegten.classList.remove("text-light");
    
}
btneleven.onclick = ()=>{
        boxtwelve.classList.add("activeInfo");
     boxeleven.classList.add("inactiveInfo");
     pegtwelve.classList.add("bg-dark");
  pegtwelve.classList.add("text-light");
     pegeleven.classList.remove("bg-dark");
	   pegeleven.classList.remove("text-light");
    
}
btntwelve.onclick = ()=>{
        boxthirteen.classList.add("activeInfo");
     boxtwelve.classList.add("inactiveInfo");
     pegthirteen.classList.add("bg-dark");
  pegthirteen.classList.add("text-light");
     pegtwelve.classList.remove("bg-dark");
	   pegtwelve.classList.remove("text-light");
    
}
btnsixes.onclick = ()=>{
       window.location="diagnosischeckout.html"; 
}

function func(){
        console.log("this is next1")

        var a = document.getElementById("one")
        var b = document.getElementById("two")
        var c = document.getElementById("three")
        var d = document.getElementById("four")
        var e = document.getElementById("five")

                if((a.checked) || (b.checked) || (c.checked) || (d.checked) || (e.checked))
                {
                        document.getElementById("next1").style.pointerEvents = 'auto'
                }
                if (($("#one").prop('checked') == false)&&($("#two").prop('checked') == false)&&($("#three").prop('checked') == false)&&($("#four").prop('checked') == false)&&($("#five").prop('checked') == false) ){
                        document.getElementById("next1").style.pointerEvents = 'none'
                }
        }

	

function func_page1(){
        var six = document.getElementById("six")
        var seven = document.getElementById("seven")

        if((six.checked) || (seven.checked))
        {
                document.getElementById("next3").style.pointerEvents = 'auto'
        } 
}

function func_page2(){
        var eight = document.getElementById("eight")
        var nine = document.getElementById("nine")

        if((eight.checked) || (nine.checked))
        {
                document.getElementById("next4").style.pointerEvents = 'auto'
        } 
}


function func_page3(){
        var ten=document.getElementById("1-2")
        var eleven=document.getElementById("2-3")
        var twelve=document.getElementById("3-4")
        var thirt=document.getElementById("sure")
        if((ten.checked) || (eleven.checked) || (twelve.checked) || (thirt.checked))
        {
                document.getElementById("next5").style.pointerEvents = 'auto'
        } 
        
}

function func_page4(){
        var fourteen=document.getElementById("ev")
        var fifteen=document.getElementById("occ")
        var sixteen=document.getElementById("not")
        if((fourteen.checked) || (fifteen.checked) || (sixteen.checked))
        {
                document.getElementById("next6").style.pointerEvents = 'auto'
        } 
        
}

function func_page5(){
        var fourteen=document.getElementById("ev2")
        var fifteen=document.getElementById("occ2")
        var sixteen=document.getElementById("not2")
        if((fourteen.checked) || (fifteen.checked) || (sixteen.checked))
        {
                document.getElementById("next7").style.pointerEvents = 'auto'
        } 
}


function func_page6(){
        var fourteen=document.getElementById("st-one")
        var fifteen=document.getElementById("st-two")
        var sixteen=document.getElementById("st-three")
        var seventeen=document.getElementById("st-four")
        var eighteen=document.getElementById("st-five")

        if((fourteen.checked) || (fifteen.checked) || (sixteen.checked) || (seventeen.checked) || (eighteen.checked))
        {
                document.getElementById("next8").style.pointerEvents = 'auto'
        } 
        
}

function func_page7(){
        console.log("i am next2 ")
        var fourteen=document.getElementById("st-1")
        var fifteen=document.getElementById("st-2")
        var sixteen=document.getElementById("st-3")
        var seventeen=document.getElementById("st-4")
        var eighteen=document.getElementById("st-5")

        if((fourteen.checked) || (fifteen.checked) || (sixteen.checked) || (seventeen.checked) || (eighteen.checked))
        {
                document.getElementById("next2").style.pointerEvents = 'auto'
        } 
        
}

function func_page8(){
        var fourteen=document.getElementById("st-6")
        var fifteen=document.getElementById("st-7")
        var sixteen=document.getElementById("st-8")
        var seventeen=document.getElementById("st-9")
        var eighteen=document.getElementById("st-10")

        if((fourteen.checked) || (fifteen.checked) || (sixteen.checked) || (seventeen.checked) || (eighteen.checked))
        {
                document.getElementById("next3").style.pointerEvents = 'auto'
        } 
        
}

function func_page9(){
        var fourteen=document.getElementById("st-11")
        var fifteen=document.getElementById("st-12")
        var sixteen=document.getElementById("st-13")
        var seventeen=document.getElementById("st-14")
        var eighteen=document.getElementById("st-15")

        if((fourteen.checked) || (fifteen.checked) || (sixteen.checked) || (seventeen.checked) || (eighteen.checked))
        {
                document.getElementById("next4").style.pointerEvents = 'auto'
        } 
        
}

function func_page10(){
        var fourteen=document.getElementById("hhcone")
        var fifteen=document.getElementById("hhctwo")
        var sixteen=document.getElementById("hhcthree")
        var seventeen=document.getElementById("hhcfour")
        var eighteen=document.getElementById("hhcfive")

        if((fourteen.checked) || (fifteen.checked) || (sixteen.checked) || (seventeen.checked) || (eighteen.checked))
        {
                document.getElementById("next5").style.pointerEvents = 'auto'
        } 
        
}

function func_page11(){
        var fourteen=document.getElementById("dpd-1")
        var fifteen=document.getElementById("dpd-2")
        var sixteen=document.getElementById("dpd-3")
        var seventeen=document.getElementById("dpd-4")
        var eighteen=document.getElementById("dpd-5")

        if((fourteen.checked) || (fifteen.checked) || (sixteen.checked) || (seventeen.checked) || (eighteen.checked))
        {
                document.getElementById("next6").style.pointerEvents = 'auto'
        } 
        
}
function func_page12(){
        var fourteen=document.getElementById("hhconec")
        var fifteen=document.getElementById("hhctwoc")
        var sixteen=document.getElementById("hhcthreec")
        var seventeen=document.getElementById("hhcfourc")
        var eighteen=document.getElementById("hhcfivec")

        if((fourteen.checked) || (fifteen.checked) || (sixteen.checked) || (seventeen.checked) || (eighteen.checked))
        {
                document.getElementById("next7").style.pointerEvents = 'auto'
        } 
        
}