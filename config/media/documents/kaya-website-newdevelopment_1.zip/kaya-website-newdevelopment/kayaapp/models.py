import os, datetime
from django.db import models
from django.contrib.postgres.fields import ArrayField
from django.contrib.auth.models import AbstractUser
from django.dispatch import receiver
from django.utils.crypto import get_random_string
from django.utils.text import slugify
from django.utils.translation import ugettext_lazy as _
from .managers import MyManager

class TimeStampMixin(models.Model):
    id = models.CharField(max_length=40,primary_key=True,editable=False)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        abstract = True
    
    def save(self,*args,**kwargs):
        if not self.id:
            self.id = datetime.datetime.now().strftime("%d%m%Y%H%M%S%f") + get_random_string(10,"0123456789")
        super(TimeStampMixin,self).save(*args,**kwargs)

class UserRegistration(AbstractUser):
    username = None
    id = models.CharField(max_length=30,primary_key=True)
    gender = models.CharField(max_length=30,blank=True,null=True)
    age = models.PositiveIntegerField(blank=True,null=True)
    email = models.EmailField(_("Email Address"),unique=True)
    token = models.CharField(max_length=256,null=True,blank=True)
    qoute_id = models.IntegerField()

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["age",'gender','first_name','last_name']
    objects = MyManager()
    
    def _str_(self):
        return self.email
    
    @staticmethod
    def exists(**kwargs):
        if UserRegistration.objects.filter(**kwargs).exists():
            return True
        return False
    
    class Meta:
        db_table='user_registation'
        verbose_name_plural = "Users"


class Diagnosis(TimeStampMixin):
    image = models.ImageField(upload_to = "image", null= False, blank = False)
    user = models.ForeignKey(UserRegistration, on_delete=models.CASCADE)
    
    def save(self,*args,**kwargs):
        super(Diagnosis,self).save(*args,**kwargs)
        
    class Meta:
        db_table='diagnosis'
        verbose_name_plural = "Diagnosis"
        

class Form1UserQuestion(TimeStampMixin):
    question = models.TextField()
    class Meta:
        db_table='form1_user_question'
        ordering = ['created']
        verbose_name_plural = "Question"
        

class Form1Option(models.Model):
    option = models.CharField(max_length=256)
    form1_user_question = models.ForeignKey(Form1UserQuestion,on_delete=models.CASCADE,related_name='options')
    class Meta:
        db_table='question_options'
        verbose_name_plural = "Option"
        


class Form1UserAnswer(TimeStampMixin):
    user = models.ForeignKey(UserRegistration,on_delete=models.CASCADE,related_name='user_form1_questions')
    question_answer = models.JSONField()
    ai_image = models.ImageField(upload_to='ai_image',blank=True,null=True)
    
    class Meta:
        db_table='form1_user_answer'
        verbose_name_plural = "Form1UserAnswer"
        


class SkinType(TimeStampMixin):
    skin_type = models.CharField(max_length=100,unique=True)
    
    class Meta:
        db_table='skin_type'
        verbose_name_plural = "SkinType"
    
    def __str__(self):
        return self.skin_type

class Concern(TimeStampMixin):
    concern_text = models.TextField(unique=True)   

    class Meta:
        db_table='concern'
        verbose_name_plural = "Concern"
    
    def __str__(self):
        return f"{self.concern_text}"

class Solution(TimeStampMixin):
    solution_text = models.TextField()
    concern = models.OneToOneField(Concern,on_delete=models.CASCADE,related_name="solutions")
    
    def _str_(self):
        return self.solution_text

    class Meta:
        db_table='solution'
        verbose_name_plural = "Solution"


class AgeGroup(models.Model):
    age_group_min = models.PositiveIntegerField(blank=True,null=True)
    age_group_max = models.PositiveIntegerField(blank=True,null=True)

    class Meta:
        db_table='AgeGroup'
        verbose_name_plural = "AgeGroup"
        
    def __str__(self):
        return f"{self.age_group_min} - {self.age_group_max}"
    

class Product(TimeStampMixin):
    name = models.CharField(max_length=512)
    description = models.TextField(blank=True,null=True)
    price = models.FloatField()
    product_image = models.ImageField(upload_to='product/images',blank=True,null=True)
    slug = models.SlugField(editable=False)
    sku_id = models.CharField(max_length=512)
    product_url = models.URLField()
    image_url = models.URLField()
    age_group = models.ManyToManyField(AgeGroup,related_name='age_group_products')
    skin_type = models.ManyToManyField(SkinType,related_name='skin_type_products')
    concern = models.ManyToManyField(Concern,related_name='concern_products')

    def save(self,*args,**kwargs):
        self.slug = slugify(self.name)
        super(Product,self).save(*args,**kwargs)

    class Meta:
        db_table='product'
        verbose_name_plural = "Product"
class UserReport(TimeStampMixin):

    user = models.ForeignKey(
        UserRegistration, on_delete=models.CASCADE, related_name="user_reports"
    )
    concerns = ArrayField(models.CharField(max_length=50), default=list)
    products_user_bought = ArrayField(models.CharField(max_length=50), default=list)
    skin_type = models.CharField(max_length=50)

    class Meta:
        db_table = "user_all_reports"
        verbose_name_plural = "User Report"