import json
from rest_framework.views import APIView,Response
from .serializers import Form1Serializer, Form1UserQuestion,ProductSerializer, Product, UserReportSerializer
from django.views.generic import View
from django.http import JsonResponse
from django.conf import settings
from collections import Counter
from kayaapp import models
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from rest_framework.decorators import api_view

@csrf_exempt
def image_upload(request):
    try:
        if request.method == "POST":
            image = request.FILES['image']
            id = request.POST['id']
            models.Diagnosis.objects.create(image=image,user=models.UserRegistration.objects.get(id=id))
            return JsonResponse({"status":"image uploaded","url":""})
        elif request.method == "DELETE":
            path = request.data['path']
            id = request.data['id']
            image = models.Diagnosis.objects.filter(user_id=id)
            if image.exists():
                base = str(settings.MEDIA_ROOT) + path.replace('media/','')
                if image.first().image.path == base:
                    image.first().delete()
                    return JsonResponse({'status':"success","message":"Image deleted","url":""})
                else:
                    return JsonResponse({'status':"failed","message":f"can not delete image not found"},status=400)
            else:
                return JsonResponse({'status':"failed","message":f"image not found"},status=400)
        else:
            return JsonResponse({"status":"success"})
    except KeyError as err:
            return JsonResponse({'status':"failed","message":f"{err} missing"},status=400)
    
class Form1QuestionAPIView(APIView):
    def get(self,request):
        serializer = Form1Serializer(Form1UserQuestion.objects.all(),many=True)
        return Response({"status":"success","data":serializer.data})

        
    def post(self,request,*args,**kwargs):
        try:
            data = request.body
            
            answers = []
            question_answer = []
            for _ , values in data.items():
                question_answer_with_option = values.split(',')
                question_answer.append({question_answer_with_option[0]:question_answer_with_option[1]})
                answers.append(question_answer_with_option[2])
            answer_count = Counter(answers)
            
            if answer_count.get('a',0) >= 5:
                skin_type = "Oily"
            elif answer_count.get('b',0) >= 5:
                skin_type = "Normal"
            elif answer_count.get('c',0) >= 5:
                skin_type = "Combination"
            elif answer_count.get('d',0) >= 5:
                skin_type = "Sensitive"
            else:
                skin_type = "Dry"
            return Response({"status":"success","message":"data submited","url":""})
        except KeyError as err:
            return Response({"status":"failed","error":f"{err} required"},status=400)
        except ValueError:
            return Response({"status":"failed"},status=400)

@api_view(['GET'])
def get_products(request):
    try:
        if request.method == "GET":
            skin_type = request.GET.get('skin_type','normal')
            concerns = request.GET['concerns']
            concerns_objs = []
            for concern in concerns.split(","):
                concerns_objs.append(models.Concern.objects.filter(concern_text__icontains=concern).first())
            age = request.user.age if request.user.is_authenticated and request.user.age is not None else 20
            products = Product.objects.filter(skin_type__skin_type__icontains=skin_type,age_group__age_group_min__lte=age,age_group__age_group_max__gte=age,concern__in=concerns_objs).distinct()
            data = ProductSerializer(products,many=True).data
            return Response({"status":"success","data":data},status=200)
        return Response({"status":"failed","message":"method not allowed"},status=405)
    except AttributeError :
        return Response({"status":"failed","message":"concerns in aaray format"},status=400)
    except KeyError as err:
        return JsonResponse({"status":"failed","message":f"{err} missing in query params"},status=400)


@method_decorator(csrf_exempt,name='dispatch')    
class UserReportApiView(View):   
    def post(self,request):
        try:
            if request.user.is_authenticated:
                data = json.loads(request.body)
                products_user_bought = data['products_user_bought']
                if not isinstance(products_user_bought,list):
                    return JsonResponse({"status":"failed","message":f"product user bought should be  in array format"},status=400)
                user_report_id = data['user_report_id']
                user_report = models.UserReport.objects.get(id=user_report_id)
                user_report.products_user_bought = products_user_bought
                user_report.save()
                return JsonResponse({"status":"success","message":"user report created"},status=201)
            else:
                return JsonResponse({"status":"failed","message":"unauthorized request"},status=401)
        except KeyError as err:
            return JsonResponse({"status":"failed","message":f"{err} missing"},status=400)
        except models.UserReport.DoesNotExist:
            return JsonResponse({"status":"failed","message":f"invalid user_report_id"},status=400)
        except Exception as err:
            return JsonResponse({"status":"failed","message":f"some thing goes wrong sue to {err}"},status=400)

