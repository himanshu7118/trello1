from .models import UserReport
from django.conf import settings

def user_report(request):
    if request.user.is_authenticated:
        user_reports = UserReport.objects.filter(user=request.user)
    else:
        user_reports = None
    return {"user_reports":user_reports,"kaya_base_url":settings.KAYA['kaya_base_url']}

