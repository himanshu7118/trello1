from rest_framework import serializers
from kayaapp.models import Form1Option, Form1UserQuestion, Product

class Form1OptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Form1Option
        fields = ['option']


class Form1Serializer(serializers.ModelSerializer):
    options = serializers.SerializerMethodField('get_options',read_only=True)
    class Meta:
        model = Form1UserQuestion
        fields = ['question','options']
        
    
    def get_options(self,obj):
        option_list = []
        for option in obj.options.all():
            option_list.append(option.option)
        return option_list

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id', 'name','description','price','product_image','sku_id','product_url','image_url']
        
class UserReportSerializer(serializers.Serializer):
    product_user_bought = serializers.ListField()
    concerns = serializers.ListField()
    skin_type = serializers.CharField()