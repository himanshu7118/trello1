from PIL import Image
from io import BytesIO
import base64
import re,sys
from django.core.files.uploadedfile import InMemoryUploadedFile
import django,json
from django.shortcuts import redirect, render, get_object_or_404
from django.urls.base import reverse
from django.contrib import messages
from collections import Counter
from django.contrib.auth import login,logout
from django.contrib.auth.decorators import login_required
from requests.api import get
from . import models
from django.http import HttpResponse
from .utils import post_request,decrypt_customer_id, get_admin_token, get_customer_token, get_qoute_id,renew_customer_and_admin_token
from django.http import JsonResponse
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from kayaapp.models import UserReport

def test(request):
    return  render (request,'kayaapp/camera.html')



# def open_camera1(request):
#     return render(request,'kayaapp/camera.html')

def upload_img(request):
    return render(request,'kayaapp/camera.html')

def prescription(request):
    return render(request,'kayaapp/prescription.html')    

def signup(request):
    
    return render(request,'kayaapp/login.html')


def loginn(request):
    return render(request,'kayaapp/login.html')

@login_required(login_url="/kaya/login/")
@renew_customer_and_admin_token
def intro1(request):
    if request.user.user_reports.all().exists():
        data = UserReport.objects.filter(user =request.user)
        if data.exists():
            return render(request,"kayaapp/camera.html")
    return render(request,'kayaapp/intro1.html')

@login_required(login_url="/kaya/login/")
@renew_customer_and_admin_token
def intro2(request):
    if request.user.user_reports.all().exists():
        data = UserReport.objects.filter(user =request.user)
        if not data.exists():
            print("this is intro2")
            return render(request,"kayaapp/camera.html")
    return render(request,'kayaapp/intro2.html')




def index(request):
    return render(request, "kayaapp/home.html")

@login_required(login_url="/kaya/login/")
@renew_customer_and_admin_token
def user_dashboard_view(request):
    user_reports = models.UserReport.objects.filter(user=request.user).order_by("-created")
    if not user_reports.exists():
        return redirect(reverse("intro1"))
    id = request.GET.get("user_report")
    age = request.user.age if request.user.is_authenticated and request.user.age is not None else 20
    user_report = user_reports.first()
    if id is not None:
        user_report = get_object_or_404(models.UserReport, id=id)
    visited_date = user_report.created
    products_user_bought = models.Product.objects.filter(id__in=user_report.products_user_bought)
    concerns_objs = []
    for concern in user_report.concerns:
        concerns_objs.append(models.Concern.objects.filter(concern_text__icontains=concern).first())
    products = models.Product.objects.filter(skin_type__skin_type__icontains=user_report.skin_type,age_group__age_group_min__lte=age,age_group__age_group_max__gte=age,concern__in=concerns_objs).distinct()
    return render(
        request,
        "kayaapp/user_dashboard.html",
        {
            "products": products,
            "user_reports": user_reports,
            "visited_date": visited_date,
            "recomoneded_products": products,
            "user_bought_prevous_products": products_user_bought,
        },
    )

def login_view(request):
    next = request.GET.get("next")
    encrypted_customer_id = request.GET.get(settings.KAYA['customer_id_query_param_name'])
    error,customer_id = decrypt_customer_id(encrypted_customer_id)
    if not error:
        status,admin_token = get_admin_token()
        if status == 200:
            status,customer_token = get_customer_token(customer_id,admin_token)
            if status == 200:
                status,customer_details = post_request("/rest/V1/ranosys-kaya/customerdata",data={"customerId":customer_id},token=admin_token)
                if status == 200:
                    if not models.UserRegistration.exists(email=customer_details[0]['email']):
                        user = models.UserRegistration.objects.create_user(id=customer_details[0]['id'],email=customer_details[0]['email'],first_name=customer_details[0]['firstname'],last_name=customer_details[0]['lastname'],gender=customer_details[0]['gender'],age=customer_details[0]['age'],token=customer_token)
                    else:
                        user = models.UserRegistration.objects.filter(email=customer_details[0]['email']).first()
                        
                        user.token = customer_token
                    user.qoute_id = get_qoute_id(user.id,customer_token)
                    user.save()
                    login(request,user)
                    request.session['admin_token'] = admin_token
                    if next:
                        return redirect(next)
                    return redirect(reverse("dashboard"))
                else:
                    error = "invalid cutomer id or admin token"
            else:
                error = "login in not possible due invalid admin"
        else:
            error = "login in not possible due invalid admin"
    else:
        error = "login in not possible due invalid customer id"
    next = request.GET.get("next")
    if next:
        path = request.build_absolute_uri(next)
        error += f"&{settings.KAYA['login_ai_redirection_url_name']}={path}"
    return redirect(settings.KAYA['kaya_login_url'] + f"?error={error}")

@login_required(login_url="/kaya/login/")
def imageupload(request):
    if request.method == 'POST':
        try:
            image = request.FILES['file']
            models.Diagnosis.objects.create(user=request.user,image=image)
        except django.http.multipartparser.MultiPartParserError:
            return redirect(reverse('form1'))
    return render(request, "kayaapp/image_upload.html")


def logout_view(request):
    logout(request)
    return redirect("/")

@login_required(login_url="/kaya/login/")
@renew_customer_and_admin_token
def diagnosis(request):
    print("this is :1")
    image= models.Diagnosis.objects.filter(user=request.user).last()
    return render(request, "kayaapp/diagnosis_image.html", {"image":image})

@login_required(login_url="/kaya/login/")
@renew_customer_and_admin_token
def open_cam(request):
    print("this is :2")
    if request.method == "POST":
        image = request.POST['image']
        buffer_plot = BytesIO()
        base64_data = re.sub('^data:image/.+;base64,', '', image)
        binary_data = base64.b64decode(base64_data)
        img_data = BytesIO(binary_data)
        img = Image.open(img_data)
        try:
            img.save(buffer_plot, format='PNG', quality=100)
        except:
            img.save(buffer_plot, format='JPEG', quality=100)
        buffer_plot.seek(0)
        final_plot= InMemoryUploadedFile(buffer_plot, 'ImageField',"plot.png",'image/png',sys.getsizeof(buffer_plot), None)
        models.Diagnosis.objects.create(user=request.user,image=final_plot)
                
        return JsonResponse({"status":"success", "url":"/kaya/form1/"})
    return render(request,'kayaapp/camera.html')

@login_required(login_url="/kaya/login/")
@renew_customer_and_admin_token
@csrf_exempt
def form1_vew(request):
    print("this is :3")
    form1_questions = models.Form1UserQuestion.objects.all()
    if request.method == "POST":
        data = json.loads(request.body)
        question_answer = []       
        answers = []
        
        for _ , values in data.items():
            question_answer_with_option = values.split(',$')
            question_answer.append({question_answer_with_option[0]:question_answer_with_option[0]})
            answers.append(question_answer_with_option[0])
        answer_count = Counter(answers)
        
        if answer_count.get('a',0) >= 3:
            skin_type = "Oily"
        elif answer_count.get('b',0) >= 3:
            skin_type = "Normal"
        elif answer_count.get('c',0) >= 3:
            skin_type = "Combination"
        elif answer_count.get('d',0) >= 3:
            skin_type = "Sensitive"
        elif answer_count.get('e',0) >= 3:
            skin_type = "Dry"
        else:
            skin_type = "Normal"
        request.session['user_skin_view_count'] = 0
        models.Form1UserAnswer.objects.create(question_answer=question_answer,user=request.user,ai_image= models.Diagnosis.objects.filter(user=request.user).last().image.url)
        return JsonResponse({"status":"success","url":f"/kaya/skin-type/{skin_type}"})
    return render(request,'kayaapp/general.html',{"form1_questions":form1_questions})

@login_required(login_url="/kaya/login/")
@renew_customer_and_admin_token
def skin_type_new(request, skin_type):
    image= models.Diagnosis.objects.filter(user=request.user).last()

    return render(request,'kayaapp/skin_type.html',{"image":image,'skin_type':skin_type})

@login_required(login_url="/kaya/login/")
@renew_customer_and_admin_token
def skin_type_view(request,skin_type):
    image= models.Diagnosis.objects.filter(user=request.user).last()
    skin_type = get_object_or_404(models.SkinType,skin_type__iexact=skin_type)
    products_list = []
    concerns_list = []
    concerns_products_dict = {}
    if request.session.get('user_skin_view_count',0):
        user_report_id = models.UserReport.objects.create(user=request.user,skin_type=skin_type,concerns=[],products_user_bought=[])
        request.session['user_report_id'] = user_report_id
    else:
        user_report_id = request.session.get('user_report_id')
    age = request.user.age if request.user.is_authenticated and request.user.age is not None else 20
    concerns_objs = []
    concerns = []
    for concern in concerns:
        concerns_objs.append(models.Concern.objects.filter(concern_text__icontains=concern).first())
    # products = models.Product.objects.filter(skin_type__skin_type__icontains=skin_type,age_group__age_group_min__lte=age,age_group__age_group_max__gte=age,concern_in=concerns_objs).distinct()
    products = models.Product.objects.all()
    return render(request,'kayaapp/new_skin_type.html',{"skin_type":skin_type,"image":image,"user_report_id":user_report_id, "products":products})

    
    
    
@login_required(login_url="/kaya/login/")
@renew_customer_and_admin_token
def product_detail_view(request):
    print("this is :7")
    response = post_request("/rest/V1/ranosys-kaya/getproductdata",token=request.session.get('admin_token'))
    if not (response[0] >= 200 and response[0] <= 299):
        token = request.session['admin_token'] = get_admin_token()[1]
        response = post_request("/rest/V1/ranosys-kaya/getproductdata",token=token)
    return redirect(response[1][1]['product_url'])


@login_required(login_url="/kaya/login/")
@renew_customer_and_admin_token
def user_report(request,id):
    print("this is :8")
    user_report = get_object_or_404(models.UserReport,id=id,user=request.user)
    return render(request,'kayaapp/user_report.html',{"user_report":user_report})

@login_required(login_url="/kaya/login/")
@renew_customer_and_admin_token
def product_detail_view(request):
    print("this is :9")
    response = post_request("/rest/V1/ranosys-kaya/getproductdata",token=request.session.get('admin_token'))
    if not (response[0] >= 200 and response[0] <= 299):
        token = request.session['admin_token'] = get_admin_token()[1]
        response = post_request("/rest/V1/ranosys-kaya/getproductdata",token=token)
    return redirect(response[1][1]['product_url'])

@login_required(login_url="/kaya/login/")
@renew_customer_and_admin_token
def user_report(request,id):
    user_report = get_object_or_404(models.UserReport,id=id,user=request.user)
    return render(request,'kayaapp/user_report.html',{"user_report":user_report})
