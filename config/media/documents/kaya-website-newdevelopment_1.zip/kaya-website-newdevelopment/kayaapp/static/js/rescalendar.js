(function($) {
    var date = $("#lastVisited").val();
    var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    jsDate = new Date(date);
    days = days[jsDate.getDay()]
    console.log(days);
    $.fn.rescalendar = function( options ) {
        function set_template( targetObj, settings ){
            template = settings.template_html( targetObj, settings );
            targetObj.html( template );
            return true;
        };      
        function setDayCells( targetObj, refDate ){
            var format   = settings.format,
                f_inicio = moment( refDate, format ).subtract(settings.jumpSize, 'days'),           
                today    = moment( ).startOf('day'),
                html            = '<td class="firstColumn"></td>',
                f_aux           = '',
                f_aux_format    = '',
                day             = '',
                weekdays        = '',               
                clase_middleDay = '',
                clase_disabled  = '',
                middleDay       = targetObj.find('input.refDate').val();
                for( var i = 0; i< (settings.calSize + 1) ; i++){
                f_aux        = moment( f_inicio ).add(i, 'days');
                f_aux_format = f_aux.format( format );
                day        = f_aux.format('DD');
                mes        = f_aux.locale( settings.locale ).format('MMM').replace('.','');
                weekdays = f_aux.locale( settings.locale ).format('dd');
             
                f_aux_format == today.format( format ) ? clase_today     = 'today'         : clase_today = '';
                html += [
                    '<td class="day_cell ' + clase_today + ' ' + clase_middleDay + ' ' + clase_disabled + '" data-cellDate="' + f_aux_format + '">',
                        '<span class="weekdays">' + weekdays + '</span>',
                        '<span class="day">' + day + '</span>',                      
                    '</td>'
                ].join('');
            }
            targetObj.find('.rescalendar_day_cells').html( html );
            addTdClickEvent( targetObj );
            setData( targetObj )      
        }
        function addTdClickEvent(targetObj){
            var day_cell = targetObj.find('td.day_cell');
            day_cell.on('click', function(e){           
                var cellDate = e.currentTarget.attributes['data-cellDate'].value;
                targetObj.find('input.refDate').val( cellDate );
                setDayCells( targetObj, moment(cellDate, settings.format) );
            });
        }
        // INITIALIZATION
        var settings = $.extend({
            id           : 'rescalendar',
            format       : 'DD-MM-YYYY',
            refDate      : moment().format( 'DD-MM-YYYY' ),
            jumpSize     : 15,
            calSize      : 30,
            locale       : 'en',
            disabledDays : [],
            disabledWeekDays: [],
            dataKeyField: 'name',
            dataKeyValues: [],
            data: {},
            template_html: function( targetObj, settings ){              
                var id      = targetObj.attr('id'),
                    refDate = settings.refDate ;
                return [
                    `<div class="rescalendar"  id="_wrapper">
                        <div class="rescalendar_controls">
                            <span class="refDate mb-4 pl-3 text-left border-0"> ${date} </span>
                        </div>
                        <table class="rescalendar_table">
                            <thead>
                                <tr class="rescalendar_day_cells"></tr>
                            </thead>
                            <tbody class="rescalendar_data_rows">                             
                            </tbody>
                        </table>                 
                    </div>`,
             ].join('');
            }
        }, options);
        return this.each( function() {          
            var targetObj = $(this);
            set_template( targetObj, settings);
            setDayCells( targetObj, settings.refDate );
            return this;
        });

    } // end rescalendar plugin


}(jQuery));